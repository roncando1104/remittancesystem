Title: VB.NET Pie / Bar / Line Chart graph Version3
Description: Version 3 of the Pie/Bar/Line graphs. I added a key generator, 3d bars, grid behind the bars and worked a little on the pie charts. Next version I will be adding values to the bar graph. Updated to VB.NET 2.0.
Can be used in ASP.NET. (Have not tested since version 1)
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=4556&lngWId=10

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
